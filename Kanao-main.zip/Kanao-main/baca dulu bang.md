Panduan dan keterangan

> Cara koneksi bot 
1. paring [Example (index.js --pairing)]

2. Mobile [Example (index.js --mobile)]

3 Default [Example (index.js)]

Note: index.js itu sesuaikan sama tempat run di bot kamu kalo npm start ya berati, npm srart --pairing begitu juga seterusnya



> Cara set apikey, nama bot dan lain lain
1. Set apikey 
Contoh: .addapi lol YourKey (untuk list api bisa di lihat di config.js)

2. Set owner
Contoh: .addrealowner 62xxx Ini untuk set real owner dan addowner 62xxx Ini untuk set owner biasa, jadi tidak usah ubh di config lagi supaya mempermudah aja sih biar ga ribet:v

3. Set nama bot

- setauthor Your Name
- setpackname Your Name Bot
- setgcnamebot Your Name Group Bot
- setteksjadibot Ubah aja sesuai kebutuhan
- setteks(donasi|sewa(bot)?|topup) Ibah aja sesuai kebutuhan

Sisanya bisa cek di .menuowner



Jika kalian tanya bang kenapa welcome ga aktif

ya jadi welcome emang ga gw aktifkan nah gimana cara mengaktifkan nya??, caranya ketik .enable welcome udah sih itu aja XD



Note: script ini gratis, jika anda menemukan ada orang yang menjual Script ini harap lapor ke
- 6281398274790
- 62895385006567